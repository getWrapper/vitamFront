App.factory("inicioConsultaService", ["$http", "$q", "RestService", "MessagesService", "RestServiceValidator", "RestConfigurationConstants", "HelloWorldEndpoint", function ($http, $q, RestService, MessagesService, RestServiceValidator, RestConfigurationConstants, HelloWorldEndpoint) {
	// URL of the web services host
	var engineUrl = RestConfigurationConstants.engineApiUrl;
	var inicioConsultaServices =  {
		
	}
	return inicioConsultaServices;
}]);
