App.factory("goodByeWorldService", ["$http", "$q", "RestService", "MessagesService", "RestServiceValidator", "RestConfigurationConstants", "HelloWorldEndpoint", function ($http, $q, RestService, MessagesService, RestServiceValidator, RestConfigurationConstants, HelloWorldEndpoint) {
	//Review the HelloWorldService file to view a complete example how to build a service
	return null;
}]);