(function() {
	App.controller('goodByeWorldController', ['$scope', '$http', 'Flash', 'MessagesService', 'FormUtilService', 'PaginatorConfigService', 'goodByeWorldService', function ($scope, $http, Flash, MessagesService, FormUtilService, PaginatorConfigService, goodByeWorldService) {
		//Review the HelloWorldController file to view a complete example how to build a controller
	}]);
})();