App.constant("HelloWorldEndpoint", {
	defaultOperation: "context-name/Operation-name"
});