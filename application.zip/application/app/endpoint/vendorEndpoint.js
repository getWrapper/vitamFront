App.constant("vendorEndpoint", {
	getContextualInfoDetail: "/contextName/operationName"
});