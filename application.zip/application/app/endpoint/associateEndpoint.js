App.constant("associateEndpoint", {
	getContextualInfoDetail: "/contextName/operationName"
});