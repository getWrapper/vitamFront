App.constant("guatemalaEndpoint", {
	AuthenticateService: "/contextName/operationName"
});