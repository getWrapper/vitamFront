App.constant("costaRicaEndpoint", {
	AuthenticateService: "/contextName/operationName"
});