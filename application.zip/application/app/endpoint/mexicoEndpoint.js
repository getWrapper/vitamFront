App.constant("mexicoEndpoint", {
	AuthenticateService: "/contextName/operationName"
});