/**
 * Main AngularJS Web Application
 */
var App = angular.module('MainApp', [ 'ngMessages', 'ngMaterial', 'ngFlash', 'ui.bootstrap', 'vAccordion', 'ngAnimate', 'ngResource', 'ngWYSIWYG', 'ngSanitize', 'pascalprecht.translate', 'angularUtils.directives.dirPagination', 'ui.router', 'ngStorage', '720kb.tooltips', 'timer', 'ui.select']);
