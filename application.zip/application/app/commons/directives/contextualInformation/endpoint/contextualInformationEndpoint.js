App.constant("ContextualInformationEndpoint", {
	getContextualInfoDetail: "/getContextualInfoDetail",
	setContextualInformationInControl: "/setContextualInformationInControl",
	setContextualInformationInPage: "/setContextualInformationInPage",
	setFAQInPage: "/setFAQInPage",
	updateFaqInPage: "/updateFaqInPage",
	deleteFaqInPage: "/deleteFaqInPage"
});