(function() {
	App.directive('contextualInformation', function() {
		return {
			templateUrl : 'app/commons/directives/contextualInformation/contextualInformationView.html'
		};
	})
})();