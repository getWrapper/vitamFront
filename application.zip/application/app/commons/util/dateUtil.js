function addMinutes(dateTime, minutes) {
    return dateTime + minutes * 60000;
}