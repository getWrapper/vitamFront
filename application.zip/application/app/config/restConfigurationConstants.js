App.constant("RestConfigurationConstants", {
	engineApiUrl: "http://148.250.45.88:2106/",
	engineApiLoginUrl : "http://148.250.45.88:2204",
	engineApiUserDetailUrl: "http://148.250.45.88:2205"
});